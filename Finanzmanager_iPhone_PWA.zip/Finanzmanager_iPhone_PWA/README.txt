MEIN FINANZMANAGER – iPhone PWA

Die App ist für den iPhone-Browser optimiert und kann als App auf den Home-Bildschirm gelegt werden.

Wichtig: iOS erlaubt die Installation einer PWA nur von einer Website (HTTPS), nicht zuverlässig direkt aus einer lokalen ZIP-Datei.
1. Dateien auf einen HTTPS-Webspace hochladen.
2. Seite in Safari öffnen.
3. Teilen -> „Zum Home-Bildschirm“.
4. Die App startet danach wie eine eigene App.

Die Finanzdaten werden lokal im Browser (localStorage) gespeichert.
